﻿using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace Arduino
{
    public partial class Form1 : Form
    {
        private SerialPort arduinoPort;
        private int bitIndex = 0;
        private string mensaje = "";
        private bool conexionActiva = false; // Bandera para activar/desactivar la conexión

        public Form1()
        {
            InitializeComponent();
            arduinoPort = new SerialPort("COM3", 9600);
            arduinoPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void btnAbrirPuerto_Click(object sender, EventArgs e)
        {
            try
            {
                if (!arduinoPort.IsOpen)
                {
                    arduinoPort.Open();
                    MessageBox.Show("Puerto abierto con éxito.");
                }
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("El puerto está en uso por otra aplicación. Por favor, ciérrala y vuelve a intentarlo.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al abrir el puerto: {ex.Message}");
            }
        }

        private void btnCerrarPuerto_Click(object sender, EventArgs e)
        {
            if (arduinoPort.IsOpen)
            {
                arduinoPort.Close();
                conexionActiva = false; // Desactiva la conexión
                label10.Text = "Close";
                MessageBox.Show("Puerto cerrado.");
            }
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            string data = arduinoPort.ReadLine().Trim();

            if (data == "#")
            {
                conexionActiva = true; // Activa la conexión
                UpdateStatusLabel("#");
                return; // Salir para no procesar el carácter "#"
            }

            if (conexionActiva)
            {
                UpdateLabels(data); // Procesa datos solo si la conexión está activa
            }
        }

        private void UpdateLabels(string data)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(UpdateLabels), data);
                return;
            }

            switch (data)
            {
                case "0":
                    if (bitIndex < 8)
                    {
                        Controls[$"label{bitIndex + 1}"].Text = "0";
                        bitIndex++;
                    }
                    break;

                case "1":
                    if (bitIndex < 8)
                    {
                        Controls[$"label{bitIndex + 1}"].Text = "1";
                        bitIndex++;
                    }
                    break;

                case "E":
                    MessageBox.Show("Mensaje completo: " + mensaje);
                    mensaje = "";
                    Controls["label9"].Text = mensaje;
                    ResetBitLabels();
                    conexionActiva = false; // Desactiva la conexión al finalizar
                    break;
            }

            if (bitIndex == 8)
            {
                string character = ConvertBitsToCharacter();
                mensaje += character;
                Controls["label9"].Text = mensaje;
                bitIndex = 0;
                ResetBitLabels();
            }
        }

        private void UpdateStatusLabel(string text)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(UpdateStatusLabel), text);
                return;
            }
            label10.Text = text;
        }

        private string ConvertBitsToCharacter()
        {
            int value = 0;
            for (int i = 0; i < 8; i++)
            {
                value = (value << 1) | int.Parse(Controls[$"label{i + 1}"].Text);
            }
            return ((char)value).ToString();
        }

        private void ResetBitLabels()
        {
            for (int i = 1; i <= 8; i++)
            {
                Controls[$"label{i}"].Text = "";
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (arduinoPort.IsOpen)
                arduinoPort.Close();
        }
    }
}
